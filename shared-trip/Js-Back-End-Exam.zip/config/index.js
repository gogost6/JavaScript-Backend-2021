module.exports = {
    COOKIE_NAME: 'SESSION_DATA',
    TOKEN_SECRET: 'my private secret secret'
}